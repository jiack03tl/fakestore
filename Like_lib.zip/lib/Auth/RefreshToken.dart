import 'package:flutter/material.dart';

class RefreshToken extends StatefulWidget {
  const RefreshToken({super.key});

  @override
  State<RefreshToken> createState() => _RefreshTokenState();
}

class _RefreshTokenState extends State<RefreshToken> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
